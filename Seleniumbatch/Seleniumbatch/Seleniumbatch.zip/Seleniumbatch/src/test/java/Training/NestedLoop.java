package Training;

public class NestedLoop {
    //static String last_name = " Lamichhane";
    public static void main(String[] args) {
        String first_name = "Rajani";
        int a = 10; //assignment operator
        int b = 10;

        if (a == b){ //comparison operator
            System.out.println("They are equal");
        } else{
            System.out.println("They are not equal");
        }

//        for(int i=1;i<=5; i++) {
//            for(int j = 1; j<=i; j++){
//                System.out.print("*");
//            }
//            System.out.println();
//        }
    }
}

//output
//*
//**
//***
//****
//*****