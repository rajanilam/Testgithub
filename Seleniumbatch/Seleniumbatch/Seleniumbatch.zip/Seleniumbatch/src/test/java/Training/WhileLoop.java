package Training;

public class WhileLoop {
}
